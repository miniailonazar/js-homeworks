/*4.1 Напишите функцию, которая возвращает куб числа. Число передается как аргумент. */

function doInCube(num) {
    return Math.pow(num, 3);
}
console.log(doInCube(2));