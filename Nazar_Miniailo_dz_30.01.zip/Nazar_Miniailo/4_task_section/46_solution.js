/* 5.6. Сделайте функцию getDigitsSum (digit - это цифра), которая параметром принимает целое число и
возвращает сумму его цифр.*/

function getDigitsSum(num) {
    let sum = 0;
    while (num > 0) {
        sum += num % 10;
        num = Math.floor(num / 10);
    }
    return sum;

}
console.log(getDigitsSum(12));