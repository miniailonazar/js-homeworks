/*5.14. Заполните массив следующим образом: в первый элемент запишите '1', во второй '22', в третий
'333' и так далее до 32.*/

const arr = [];
const num = 32;
let res = "";
for (let i = 1; i <= num; i++){
    for (let j = 0; j < i; j++){
        res += String(i);
    }
    arr.push(res);
    res = "";
}
console.log(arr);
