/*5.11. Дан массив [1, 2, 3]. Сделайте из него массив [3, 2, 1].*/

const arr = [1, 2, 3];
arr.sort(function(a, b) {
    return b - a;
});
console.log(arr);