/*5.23 Сделайте функцию isInArray, которая определяет, есть ли в массиве элемент с заданой подстрокой
или нет. Функция первым параметром должна принимать текст, а вторым - массив, в котором делается
поиск. Функция должна возвращать true или false.*/

const arr = ["mom", "dad", "son"];
function findInArr(arr, str) {
    return arr.includes(str, 0);
}
console.log(findInArr(arr, "san"));