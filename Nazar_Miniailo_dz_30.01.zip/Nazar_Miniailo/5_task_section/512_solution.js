/* 5.12. Дан массив [3, 4, 1, 2, 7]. Отсортируйте его по убыванию.*/

const arr = [3, 4, 1, 2, 7];
arr.sort(function(a, b) {
    return b - a;
});
console.log(arr);