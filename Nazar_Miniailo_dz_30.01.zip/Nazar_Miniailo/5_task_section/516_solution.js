/*5.16. Дан массив с числами. Не используя метода reverse переверните его элементы в обратном порядке.*/

let arr = [4, 2, 5, 19, 13, 0, 10];
let len = arr.length;
for (let i = len - 1; i >= 0; i--){
    arr.push(arr[i]);
    
}
console.log(arr.slice(len));