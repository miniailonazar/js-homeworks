/*5.13. Дан массив с числами. Узнайте сколько элементов с начала массива надо сложить, чтобы в сумме
получилось больше 10-ти.*/

const arr = [3, 4, 1, 2, 7];
let res = 0;
for (let i = 0; i < arr.length; i++){
    res += arr[i];
    if (res > 10) {
        console.log(i+1);
        break;
    } else {
        continue;
    }
}