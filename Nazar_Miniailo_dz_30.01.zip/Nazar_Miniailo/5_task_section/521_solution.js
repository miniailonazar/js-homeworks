/*5.22 Дан массив с числами. Проверьте, есть ли в нем два одинаковых числа подряд. Если есть - выведите
true, а если нет - выведите false. Оформите код в виде функции.*/
const arr = [1, 2, 3, 5, 5, 3, 7];
function findIndentical(arr) {
    let con = [];
    for (let i = 0; i < arr.length; i++){
        if (arr[i] === arr[i + 1]) {
            con.push(true);
        } else {
            con.push(false);
        }
    }
    return con.includes(true, 0);
}
console.log(findIndentical(arr));