/*5.20 Дан объект {js:['jQuery', 'Angular'], php: 'hello', css: 'world'}. Выведите с его помощью
слово 'jQuery'.*/

let obj = {
    js: ['jQuery', 'Angular'],
    php: 'hello',
    css: 'world'
}
console.log(obj.js[0]);