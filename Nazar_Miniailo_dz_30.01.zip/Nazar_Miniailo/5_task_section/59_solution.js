/*5.9. Дан массив ['я', 'учу', 'javascript', '!']. С помощью метода join преобразуйте массив в
строку 'я+учу+javascript+!'.*/

const arr = ['я', 'учу', 'javascript', '!'];
let d = arr.join("+");
console.log(d);