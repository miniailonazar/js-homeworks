/*1.5. Создайте переменные firstPart = 'Привет, ' и secondPart = 'Мир!'. С помощью этих
переменных и операции сложения строк выведите на экран фразу 'Привет, Мир!'. */

const firstPart = "Привет, ";
const secondPart = "Мир!";
console.log(`${firstPart} ${secondPart}`);