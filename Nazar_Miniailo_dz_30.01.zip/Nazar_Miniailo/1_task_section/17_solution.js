/* 1.7. Создайте переменную num и присвойте ей значение '12345'. Найдите произведение (умножение)
цифр этого числа */

let num = "12345";
let num1 = Number(num);
let res = 1;
while ((num1 / 10) > 1) {
    let k = num1 % 10;
    num1 = (num1 - k) / 10;
    res *= k;
}
console.log(res);