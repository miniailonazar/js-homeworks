/*1.3. Напишите код, который считает количество секунд в месяце.*/

let secInMonth = 60 * 60 * 24 * 30;
console.log(secInMonth);