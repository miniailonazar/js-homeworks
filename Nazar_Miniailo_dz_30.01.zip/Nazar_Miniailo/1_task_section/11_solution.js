/*1.1. Создайте переменную message и присвойте ей значение 'abcde'. Обращаясь к отдельным символам
этой строки выведите на экран символ 'a', символ 'b' и символ 'e'. */

const massage = "abcde";
console.log(massage[0]);
console.log(massage[1]);
console.log(massage[4]);