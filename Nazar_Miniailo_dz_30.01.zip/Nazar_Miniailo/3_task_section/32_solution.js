/*3.2. Выведите столбец четных чисел в промежутке от 0 до 100. Выполните задание используя все виды
циклов */

let i = 0;
while (i <= 100) {
    console.log(i);
    i++;
}

let i = 0;
do {
    console.log(i);
    i++; 
} while (i <= 100)

for (let i = 0; i <= 100; i++){
    console.log(i);
}