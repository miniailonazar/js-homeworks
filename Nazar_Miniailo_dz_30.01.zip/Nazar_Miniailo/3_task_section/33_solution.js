/*3.3. С помощью цикла найдите сумму чисел от 1 до 100. Выполните задание используя все виды циклов */

let sum = 0;
for (let i = 1; i <= 100; i++){
    sum += i;
}

console.log(sum);
let i = 1;
let sum = 0;
while (i <= 100) {
    sum += i;
    i++;
} 

console.log(sum);
let i = 1;
let sum = 0;
do {
    sum += i;
    i++;
} while (i <= 100)
console.log(sum);