/*2.3. Переменная language может принимать 2 значения: 'ru' или 'en'. Если она имеет значение 'ru', то
в переменную message запишите сообщение Хорошего дня!, а если имеет значение 'en' – то это же
сообщение, но на английском (Have a nice day!). Выведите message.
Решите задачу через if и через switch-case. */

let language = "en";
if (language === "ru") {
    console.log("Хорошего дня!");
} else if (language === "en") {
    console.log("Have a nice day!");
}

let language = "ru";
switch (language) {
    case "ru":
        console.log("Хорошего дня!");
        break;
    case "en":
        console.log("Have a nice day!");
        break;
}