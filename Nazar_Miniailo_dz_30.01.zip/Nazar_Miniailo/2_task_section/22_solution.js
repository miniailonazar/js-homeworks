/* 2.2. В переменной minutes лежит число от 0 до 59 (количество минут). Определите в какую четверть часа
попадает это число (в первую, вторую, третью или четвертую). */

let minutes = 55;

if (minutes >= 0 && minutes <= 15) {
    console.log("Первая четверть");
} else if (minutes > 15 && minutes <= 30) {
    console.log("Вторая четверть");
} else if (minutes > 30 && minutes <= 45) {
    console.log("Третья четверть");
} else {
    console.log("Четвертая четверть");
}